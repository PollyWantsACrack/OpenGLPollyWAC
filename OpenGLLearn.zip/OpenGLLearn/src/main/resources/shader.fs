#version 330 core
out vec4 FragColor;

in vec2 texCord;
in vec3 ourColor;

uniform sampler2D ourTexture;
uniform sampler2D ourTexture1;
uniform float textureView;


void main() {
    //FragColor = texture(ourTexture, texCord);





        FragColor = mix(texture(ourTexture, texCord), texture(ourTexture1, texCord), textureView);

}


