package Okno;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL46;

import static org.lwjgl.glfw.GLFW.GLFW_CURSOR;
import static org.lwjgl.glfw.GLFW.GLFW_CURSOR_DISABLED;

public class WindowSetup {

    long window;
    public long setWindow(int widthh,int heighth){

        GLFWErrorCallback.createPrint(System.err).set();

        if (!GLFW.glfwInit()) {
            throw new IllegalStateException("Nie można zainicjować GLFW");
        }

        // Ustawienia wersji OpenGL 3.3 Core Profile
        GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MAJOR, 3);
        GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MINOR, 3);
        GLFW.glfwWindowHint(GLFW.GLFW_OPENGL_PROFILE, GLFW.GLFW_OPENGL_CORE_PROFILE);

        // Tworzenie okna
        window = GLFW.glfwCreateWindow(widthh, heighth, "gra", 0, 0);
        if (window == 0) {
            throw new RuntimeException("Nie można stworzyć okna");
        }


        // Ustawienie kontekstu
        GLFW.glfwMakeContextCurrent(window);
        GLFW.glfwShowWindow(window);
        GL.createCapabilities();

        GLFW.glfwSetFramebufferSizeCallback(window, (win, width, height) -> {
            GL46.glViewport(0, 0, width, height);
        });

        GL46.glViewport(0, 0, widthh, heighth);
        return window;
    }
}
