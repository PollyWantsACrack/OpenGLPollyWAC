package Camera;

import Okno.Window;
import org.joml.Math;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class Camera {






    Vector3f cameraPos = new Vector3f(0.0f, 0.0f, 3.0f);
    Vector3f cameraFront = new Vector3f(0.0f, 0.0f, -1.0f);
    Vector3f cameraUp = new Vector3f(0.0f, 1.0f, 0.0f);



    public void setCameraFront(Vector3f cameraFront) {
        this.cameraFront = cameraFront;
    }


    float fov = 45.5f;

    public Matrix4f getViewMatrix(){
        Matrix4f viewMatrix = new Matrix4f();
        viewMatrix.lookAt(cameraPos, new Vector3f(cameraPos).add(cameraFront), cameraUp);
        return viewMatrix;
    }
    public Matrix4f getProjectionMatrix(){
        Matrix4f projectionMatrix = new Matrix4f();
        projectionMatrix.perspective((float) Math.toRadians(fov),(float) 800 / 600, 0.1f, 100.0f);
        return projectionMatrix;
    }
    public Vector3f getCameraPos(){
        return cameraPos;
    }
    public Vector3f getCameraFront(){
        return cameraFront;
    }
    public Vector3f getCameraUp(){
        return cameraUp;
    }




}
