#version 330 core
out vec4 FragColor;

in vec2 texCord;
in vec3 ourColor;

uniform sampler2D ourTexture;
uniform float textureView;
uniform vec3 objectColor;
uniform vec3 lightColor;

void main() {
    //FragColor = texture(ourTexture, texCord);






        //FragColor = texture(ourTexture,texCord);
        float ambientStrength = 0.1;
        vec3 ambient = ambientStrength * lightColor;

        vec3 result = ambient * objectColor;
        FragColor = vec4(result, 1.0);


}




