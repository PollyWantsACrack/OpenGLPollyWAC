package Trashbin;
import org.joml.Matrix4f;
import org.joml.Vector4f;

public class TransformExample {
    public static void main(String[] args) {
        // Wektor (1, 0, 0, 1)
        Vector4f vec = new Vector4f(1.0f, 0.0f, 0.0f, 1.0f);

        // Macierz jednostkowa 4x4
        Matrix4f trans = new Matrix4f();

        // Translacja
        trans.rotate((float) Math.toRadians(90), 1.0f,0.0f,1.0f);
        trans.scale(0.5f,0.5f,0.5f);

        // Przemnożenie wektora przez macierz
        vec = trans.transform(vec);

        // Wyświetlenie wyników
        System.out.println("Transformation Matrix:");
        System.out.println(trans);
    }
}
