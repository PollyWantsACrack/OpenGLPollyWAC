package Trashbin;
import org.lwjgl.opengl.GL46;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryStack;

public class passMatrix {
    public static void setUniformMatrix4f(int programId, String uniformName) {
        Matrix4f trans = new Matrix4f();

        // Obrót o 90 stopni wokół osi Z (przekształcenie stopni na radiany)
        trans.rotate((float) Math.toRadians(90), 0.0f, 0.0f, 1.0f);

        // Skalowanie
        trans.scale(0.5f, 0.5f, 0.5f);

        int uniformLocation = GL46.glGetUniformLocation(programId, uniformName);
        try (MemoryStack stack = MemoryStack.stackPush()) {
            // Przekazanie macierzy do uniform
            GL46.glUniformMatrix4fv(uniformLocation, false, trans.get(stack.mallocFloat(16)));
        }
    }
}
