package Matrixes;

import org.joml.Matrix4f;

public class ViewMatrix {
    Matrix4f viewMatrix;
    public ViewMatrix(){
        viewMatrix = new Matrix4f();
        viewMatrix.translate(0.0f, 0.0f, -3.0f);
    }
    public Matrix4f getModelMatrix(){
        return viewMatrix;
    }
}
