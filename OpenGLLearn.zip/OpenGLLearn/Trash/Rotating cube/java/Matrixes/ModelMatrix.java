package Matrixes;

import org.joml.Matrix4f;
import org.joml.Math;
import org.joml.Vector3f;

import static org.lwjgl.glfw.GLFW.glfwGetTime;

public class ModelMatrix {
    Matrix4f modelMatrix;
    public ModelMatrix(){
        modelMatrix = new Matrix4f();
        modelMatrix.rotate((float)glfwGetTime() * (float)Math.toRadians(50.0f), new Vector3f(0.5f, 1.0f, 0.0f));



    }
    public Matrix4f getModelMatrix(){
        return modelMatrix;
    }

}
