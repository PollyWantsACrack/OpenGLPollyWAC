package ModelMatrix;

import org.joml.Math;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class ModelMatrix {
    Matrix4f modelMatrix = new Matrix4f();
    public Matrix4f getModelMatrix(float time,float x,float y,float z) {
        modelMatrix = new Matrix4f();
        modelMatrix.rotate((float) Math.toRadians(time*100), new Vector3f(0.5f, 0.7f, 0.2f).normalize());
        modelMatrix.translate(new Vector3f(x,y,z));
        return modelMatrix;
    }
}
