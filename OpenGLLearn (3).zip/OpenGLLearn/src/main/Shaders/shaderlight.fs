#version 330 core
out vec4 FragColor;



uniform sampler2D ourTexture;
uniform float textureView;


void main() {
    //FragColor = texture(ourTexture, texCord);






        //FragColor = texture(ourTexture,texCord);
        FragColor = vec4(1.0f);




}


