package org.example;

import Okno.Window;


public class Main {
    public static void main(String[] args) {
        try {
            // Your application code here
            Window window = new Window();
            window.run();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}