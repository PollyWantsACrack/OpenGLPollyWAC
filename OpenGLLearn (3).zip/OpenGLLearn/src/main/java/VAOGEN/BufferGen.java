package VAOGEN;

import Okno.Vertices;
import org.lwjgl.opengl.GL46;

public class BufferGen {
//    int[] VAO;
//    int[] VBO;
//
//    public void VaoVboSet(int size) {
//        VBO = new int[size];
//        VAO = new int[size];
//        GL46.glGenVertexArrays(getVAO());
//        GL46.glGenBuffers(getVBO());
//    }
//    public int[] getVAO(){
//        return VAO;
//    }
//    public int[] getVBO(){
//        return VBO;
//    }
//    public void setBuffers(int VaoId, int VboId,float vertices[]){
//        GL46.glBindVertexArray(VAO[VaoId]);
//        GL46.glBindBuffer(GL46.GL_ARRAY_BUFFER, VBO[VboId]);
//        GL46.glBufferData(GL46.GL_ARRAY_BUFFER, vertices, GL46.GL_STATIC_DRAW);
//
//
//
//
////        GL46.glVertexAttribPointer(1,2, GL46.GL_FLOAT, false,5*Float.BYTES,3*Float.BYTES);
////        GL46.glEnableVertexAttribArray(1);
//
//
//
//
//    }
//    public void bindVAO(int VaoId){
//        GL46.glBindVertexArray(VAO[VaoId]);
//
//    }
}
