package Shadery;

import org.joml.Matrix4f;
import org.lwjgl.opengl.GL46;
import org.lwjgl.system.MemoryStack;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;

public class Shader {
    private final int ID;
    public Shader(String vertexPath, String fragmentPath){
        String vertexShaderSource = getShaderSource(vertexPath);
        String fragmentShaderSource = getShaderSource(fragmentPath);

        int vertexShader = GL46.glCreateShader(GL46.GL_VERTEX_SHADER);
        GL46.glShaderSource(vertexShader,vertexShaderSource);
        GL46.glCompileShader(vertexShader);
        int successVS = GL46.glGetShaderi(vertexShader, GL46.GL_COMPILE_STATUS);
        if(successVS == GL46.GL_FALSE){
            String infolog = GL46.glGetShaderInfoLog(vertexShader,512);
            System.out.println("ERROR::SHADER::VERTEX::COMPILATION_FAILED\n " + infolog);
        }


        int fragmentShader = GL46.glCreateShader(GL46.GL_FRAGMENT_SHADER);
        GL46.glShaderSource(fragmentShader, fragmentShaderSource);
        GL46.glCompileShader(fragmentShader);
        int successFS = GL46.glGetShaderi(fragmentShader, GL46.GL_COMPILE_STATUS);
        if(successFS == GL46.GL_FALSE){
            String infolog = GL46.glGetShaderInfoLog(fragmentShader,512);
            System.out.println("ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" + infolog);
        }


        ID = GL46.glCreateProgram();
        GL46.glAttachShader(ID, vertexShader);
        GL46.glAttachShader(ID, fragmentShader);
        GL46.glLinkProgram(ID);

        GL46.glDeleteShader(vertexShader);
        GL46.glDeleteShader(fragmentShader);

        int successSP = GL46.glGetProgrami(ID, GL46.GL_LINK_STATUS);
        if (successSP == GL46.GL_FALSE) {

            String infolog = GL46.glGetProgramInfoLog(ID, 512);
            System.out.println("ERROR::PROGRAM::LINKING_FAILED\n" + infolog);
        }


    }
    public void useShaderProgram(){
        GL46.glUseProgram(ID);
    }
    public void setIntUniform(String name, int value) {
        int location = GL46.glGetUniformLocation(ID, name);
        GL46.glUniform1i(location, value);
    }
    public void setFloatUniform(String name, float value){
        int location = GL46.glGetUniformLocation(ID,name);
        GL46.glUniform1f(location,value);
    }
    public void setMatrix4fUniform(String name, Matrix4f matrix) {
        int location = GL46.glGetUniformLocation(ID, name);
        GL46.glUniformMatrix4fv(location, false, matrix.get(new float[16]));
    }
    public void setFloat3Uniform(String name, float value,float value1,float value2){
        int location = GL46.glGetUniformLocation(ID,name);
        GL46.glUniform3f(location,value,value1,value2);
    }





    private String getShaderSource(String path) {
        try {
            Path filePath = Paths.get(path);
            byte[] fileBytes = Files.readAllBytes(filePath);

            String fileContent = new String(fileBytes);

            return fileContent;
        } catch (IOException e) {
            System.err.println("Błąd podczas odczytu pliku shaderowego: " + path);

            throw new RuntimeException(e);
        }
    }

}
