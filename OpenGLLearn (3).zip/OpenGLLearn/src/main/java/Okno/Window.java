package Okno;

import Camera.Camera;
import ModelMatrix.ModelMatrix;
import VAOGEN.BufferGen;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWCursorPosCallback;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL46;
import Shadery.Shader;
import org.joml.Math;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL46.GL_TRIANGLES;


public class Window {

    float mixValue;
    float fov = 45.0f;
    Shader[] shaderProgram = new Shader[2];
    private float time;



    boolean firstMouse = true;

    float deltaTime = 0.0f;	// time between current frame and last frame
    float lastFrame = 0.0f;

    WindowSetup setup = new WindowSetup();
    ModelMatrix modelMatrix = new ModelMatrix();

    private long window = setup.setWindow(800,600);


    float lastPosX = (float) SCR_WIDTH/2;
    float lastPosY = (float) SCR_HEIGHT/2;

    float pitch= 0.0f;
    float yaw = 0.0f;



    private int[] textureID = new int[3];
    public static final int SCR_WIDTH = 800;
    public static final int SCR_HEIGHT = 600;

    BufferGen bufferGen = new BufferGen();




    Vertices vertices = new Vertices();





    int indices[] = {
            0, 1, 3, // pierwszy trójkąt
            1, 2, 3  // drugi trójkąt
    };



    int VAO;
    int VAO1;
    int VBO;
    int VBO1;



    public void run(){
        init();
        loop();
        ending();
    }


    private void init(){



        shaderProgram[0] = new Shader("C:\\Users\\uczen\\Downloads\\OpenGLLearn\\src\\main\\Shaders\\shader.vs", "C:\\Users\\uczen\\Downloads\\OpenGLLearn\\src\\main\\Shaders\\shader.fs");
        shaderProgram[1] = new Shader("C:\\Users\\uczen\\Downloads\\OpenGLLearn\\src\\main\\Shaders\\shaderlight.vs", "C:\\Users\\uczen\\Downloads\\OpenGLLearn\\src\\main\\Shaders\\shaderlight.fs");
        textureID[0] = TextureLoader.loadTexture("C:\\Users\\uczen\\Downloads\\OpenGLLearn\\src\\main\\resources\\textureContainer.jpg");
        textureID[1] = TextureLoader.loadTexture("C:\\Users\\uczen\\Downloads\\OpenGLLearn\\src\\main\\resources\\textureFace.jpg");
        textureID[2] = TextureLoader.loadTexture("C:\\Users\\uczen\\Downloads\\OpenGLLearn\\src\\main\\resources\\textureWall.jpg");

        // Ustawienie widoku (viewport)


        // Callback przy zmianie rozmiaru okna (opcjonalnie, jeśli wymagane)

        GLFW.glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);

        GL46.glEnable(GL46.GL_DEPTH_TEST);
        // Rejestrujemy funkcję callback, która ma być wywołana przy każdym ruchu myszy.
        GLFW.glfwSetCursorPosCallback(window, new GLFWCursorPosCallback() {
            @Override
            public void invoke(long window, double xpos, double ypos) {
                moveMouse((float) xpos,(float) ypos);
            }
        });




//        bufferGen.VaoVboSet(2);
//
//        bufferGen.setBuffers(0, 0, vertices.verticesofLight);
//        GL46.glVertexAttribPointer(0, 3, GL46.GL_FLOAT, false, 3 * Float.BYTES, 0);
//        GL46.glEnableVertexAttribArray(0);
//        GL46.glVertexAttribPointer(1, 3, GL46.GL_FLOAT, false, 5 * Float.BYTES, 0);
//        GL46.glEnableVertexAttribArray(1);
//
//
//
//// Set up the second VAO and VBO for the light
//        bufferGen.setBuffers(1, 1, vertices.verticesofLight);
//        GL46.glVertexAttribPointer(0, 3, GL46.GL_FLOAT, false, 3 * Float.BYTES, 0);
//        GL46.glEnableVertexAttribArray(0);





        VAO = GL46.glGenVertexArrays();
        VAO1 = GL46.glGenVertexArrays();
        VBO = GL46.glGenBuffers();
        VBO1 = GL46.glGenBuffers();

        GL46.glBindVertexArray(VAO);
        GL46.glBindBuffer(GL46.GL_ARRAY_BUFFER, VBO);
        GL46.glBufferData(GL46.GL_ARRAY_BUFFER, vertices.verticesofCube, GL46.GL_STATIC_DRAW);
        GL46.glVertexAttribPointer(0, 3, GL46.GL_FLOAT, false, 6 * Float.BYTES, 0);
        GL46.glEnableVertexAttribArray(0);
        GL46.glVertexAttribPointer(1, 3, GL46.GL_FLOAT, false, 6 * Float.BYTES, 3*Float.BYTES);
        GL46.glEnableVertexAttribArray(1);

        GL46.glBindVertexArray(VAO1);
        GL46.glBindBuffer(GL46.GL_ARRAY_BUFFER, VBO1);
        GL46.glBufferData(GL46.GL_ARRAY_BUFFER, vertices.verticesofLight, GL46.GL_STATIC_DRAW);
        GL46.glVertexAttribPointer(0, 3, GL46.GL_FLOAT, false, 3 * Float.BYTES, 0);
        GL46.glEnableVertexAttribArray(0);






    }
    Camera camera = new Camera();

    Vector3f cameraPos = new Vector3f();
    Vector3f cameraFront = new Vector3f();
    Vector3f cameraUp = new Vector3f();

    private void loop() {
        while (!GLFW.glfwWindowShouldClose(window)) {
            float currentFrame = (float) GLFW.glfwGetTime();

            deltaTime = currentFrame - lastFrame;
            lastFrame = currentFrame;
            processInput(window);
            time = (float) glfwGetTime();


            cameraPos = camera.getCameraPos();
            cameraFront = camera.getCameraFront();
            cameraUp = camera.getCameraUp();




            GL46.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            GL46.glClear(GL46.GL_COLOR_BUFFER_BIT | GL46.GL_DEPTH_BUFFER_BIT);
            GL46.glActiveTexture(GL46.GL_TEXTURE0);
            GL46.glBindTexture(GL46.GL_TEXTURE_2D, textureID[2]);


            shaderProgram[0].useShaderProgram();



            shaderProgram[0].setMatrix4fUniform("viewMatrix", camera.getViewMatrix());
            shaderProgram[0].setMatrix4fUniform("projectionMatrix", camera.getProjectionMatrix());
            shaderProgram[0].setMatrix4fUniform("modelMatrix", modelMatrix.getModelMatrix(0,0,0,0,1f));

            shaderProgram[0].setFloat3Uniform("objectColor", 1.0f, 0.5f, 0.31f);
            shaderProgram[0].setFloat3Uniform("lightColor",  1.0f, 1.0f, 1.0f);

            GL46.glBindVertexArray(VAO);
            GL46.glDrawArrays(GL_TRIANGLES, 0, 36);



            shaderProgram[1].useShaderProgram();



            shaderProgram[1].setMatrix4fUniform("viewMatrix", camera.getViewMatrix());
            shaderProgram[1].setMatrix4fUniform("projectionMatrix", camera.getProjectionMatrix());
            shaderProgram[1].setMatrix4fUniform("modelMatrix", modelMatrix.getModelMatrix(0,1.2f, 1.0f, 2.0f,0.5f));
            GL46.glBindVertexArray(VAO1);

            GL46.glDrawArrays(GL_TRIANGLES, 0, 36);



//            for(int i = 0; i < cubePositions.length; i++){
//                Matrix4f modelMatrix;
//
//                modelMatrix = new Matrix4f();
//                modelMatrix.translate(cubePositions[i]);
//                float angle = 20.0f * i;
//                modelMatrix.rotate((float) Math.toRadians(time*120), new Vector3f(0.5f, 0.7f, 0.2f).normalize());
//
//
//                shaderProgram.setMatrix4fUniform("modelMatrix", modelMatrix);
//                GL46.glDrawArrays(GL_TRIANGLES, 0, 36);
//
//            }


            GLFW.glfwPollEvents();
            GLFW.glfwSwapBuffers(window);
        }
    }



    void processInput(long window) {
        float cameraSpeed = (float) (3 * deltaTime);

        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS) {
            GLFW.glfwSetWindowShouldClose(window, true);
        }
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_W) == GLFW.GLFW_PRESS) {
            cameraPos.add(new Vector3f(cameraFront).mul(cameraSpeed,0,cameraSpeed));
        }
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_S) == GLFW.GLFW_PRESS) {
            cameraPos.add(new Vector3f(cameraFront).mul(-cameraSpeed,0,-cameraSpeed));
        }
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_A) == GLFW.GLFW_PRESS) {
            Vector3f cross = new Vector3f(cameraUp).cross(cameraFront); // Oblicz iloczyn wektorowy
            cameraPos.add(new Vector3f(cross).mul(cameraSpeed)); // Skaluj i dodaj do pozycji kamery

        }
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_D) == GLFW.GLFW_PRESS) {
            Vector3f cross = new Vector3f(cameraUp).cross(cameraFront); // Oblicz iloczyn wektorowy
            cameraPos.add(new Vector3f(cross).mul(-cameraSpeed)); // Skaluj i dodaj do pozycji kamery

        }
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_SPACE) == GLFW.GLFW_PRESS) {
            cameraPos.add(new Vector3f(0.0f,0.001f,0.0f));
        }
        if (GLFW.glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS) {
            cameraPos.sub(new Vector3f(0.0f,0.001f,0.0f));
        }
    }
    void moveMouse(float xPos,float yPos){
        if (firstMouse) {
            lastPosX = xPos;
            lastPosY = yPos;
            firstMouse = false; // Zresetuj flagę, bo obsłużono pierwszy ruch
        }
        float Xoffset;
        float Yoffset;
        float senitivity = 0.5f;

        Xoffset = xPos - lastPosX;
        Yoffset = lastPosY - yPos;
        lastPosX = xPos;
        lastPosY = yPos;

        Xoffset = Xoffset*senitivity;
        Yoffset = Yoffset*senitivity;

        pitch = pitch + Yoffset;
        yaw = yaw -  Xoffset;

        if(pitch > 89.0f){
            pitch = 89.0f;
        } else if (pitch < -89.0f) {
            pitch = -89.0f;
        }


        Vector3f front = new Vector3f();
        front.x = (float) Math.cos(Math.toRadians(pitch)) * (float) Math.sin(Math.toRadians(yaw));
        front.y = (float) Math.sin(Math.toRadians(pitch));
        front.z = (float) Math.cos(Math.toRadians(pitch)) * (float) Math.cos(Math.toRadians(yaw));
        cameraFront = front.normalize();
        camera.setCameraFront(cameraFront);
        System.out.println(front.x);


    }



    private void ending(){
        GLFW.glfwDestroyWindow(window);
        GLFW.glfwTerminate();
        GLFW.glfwSetErrorCallback(null).free();

    }
}

