package Okno;
import org.lwjgl.opengl.GL46;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;



public class TextureLoader {
    public static int loadTexture(String filePath){

        STBImage.stbi_set_flip_vertically_on_load(true);
        int textureID = GL46.glGenTextures();
        GL46.glBindTexture(GL46.GL_TEXTURE_2D, textureID);
        GL46.glTexParameteri(GL46.GL_TEXTURE_2D, GL46.GL_TEXTURE_WRAP_S, GL46.GL_REPEAT);
        GL46.glTexParameteri(GL46.GL_TEXTURE_2D, GL46.GL_TEXTURE_WRAP_T, GL46.GL_REPEAT);
        GL46.glTexParameteri(GL46.GL_TEXTURE_2D, GL46.GL_TEXTURE_MIN_FILTER, GL46.GL_NEAREST);
        GL46.glTexParameteri(GL46.GL_TEXTURE_2D, GL46.GL_TEXTURE_MAG_FILTER, GL46.GL_NEAREST);


        try(MemoryStack stack = MemoryStack.stackPush()){
            IntBuffer widthBuffer = stack.mallocInt(1);
            IntBuffer heightBuffer = stack.mallocInt(1);
            IntBuffer channelsBuffer = stack.mallocInt(1);

            ByteBuffer data = STBImage.stbi_load(filePath, widthBuffer, heightBuffer, channelsBuffer, 3);
            if (data != null) {
                int width = widthBuffer.get(0);
                int height = heightBuffer.get(0);
                int channels = channelsBuffer.get(0);

                System.out.println("Szerokość: " + width);
                System.out.println("Wysokość: " + height);
                System.out.println("Kanały: " + channels);

                System.out.println("Texture loaded with width: " + width + ", height: " + height); // Debug
                GL46.glTexImage2D(GL46.GL_TEXTURE_2D, 0, GL46.GL_RGB, width, height, 0, GL46.GL_RGB, GL46.GL_UNSIGNED_BYTE, data);
                GL46.glGenerateMipmap(GL46.GL_TEXTURE_2D);
                STBImage.stbi_image_free(data);
            } else {
                throw new RuntimeException("Failed to load texture: " + filePath + "\n" + STBImage.stbi_failure_reason());
            }

        }
        return textureID;
        }


}

