package Matrixes;

import org.joml.Matrix4f;
import org.joml.Vector3f;

public class ProjectionMatrix {
    Matrix4f projectionMatrix;
    public ProjectionMatrix(){
        projectionMatrix = new Matrix4f();
        projectionMatrix.perspective((float) Math.toRadians(45.0f), 800.0f / 600.0f, 0.1f, 100.0f);
    }
    public Matrix4f getModelMatrix(){
        return projectionMatrix;
    }

}
