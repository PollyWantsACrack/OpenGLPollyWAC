#version 330 core
out vec4 FragColor;

in vec2 texCord;
in vec3 ourColor;

uniform sampler2D ourTexture;
uniform float textureView;


void main() {
    //FragColor = texture(ourTexture, texCord);






        FragColor = texture(ourTexture,texCord);


}




