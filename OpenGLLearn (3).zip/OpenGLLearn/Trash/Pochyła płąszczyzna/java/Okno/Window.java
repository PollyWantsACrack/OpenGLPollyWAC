package Okno;

import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL46;
import Shadery.Shader;
import org.joml.Math;
import static org.lwjgl.opengl.GL11.GL_TRIANGLES;


public class Window {
    private long window;
    float mixValue;

    Shader shaderProgram;
    private float time;



    float vertices[] = {
            // x,    y,    z,     r, g, b,     u, v
            0.5f,  0.5f, 0.0f, 1.0f, 1.0f, // Górny prawy
            0.5f, -0.5f, 0.0f, 1.0f, 0.0f, // Dolny prawy
            -0.5f, -0.5f, 0.0f,0.0f, 0.0f, // Dolny lewy
            -0.5f,  0.5f, 0.0f,0.0f, 1.0f  // Górny lewy
    };







    int indices[] = {
            0, 1, 3, // pierwszy trójkąt
            1, 2, 3  // drugi trójkąt
    };


    int[] VBO = new int[2];
    int[] VAO = new int[2];
    int[] EBO = new int[2];

    private int[] textureID = new int[2];




    public void run(){
        init();
        loop();
        ending();
    }

    private void init(){
        GLFWErrorCallback.createPrint(System.err).set();

        if (!GLFW.glfwInit()) {
            throw new IllegalStateException("Nie można zainicjować GLFW");
        }

        // Ustawienia wersji OpenGL 3.3 Core Profile
        GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MAJOR, 3);
        GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MINOR, 3);
        GLFW.glfwWindowHint(GLFW.GLFW_OPENGL_PROFILE, GLFW.GLFW_OPENGL_CORE_PROFILE);

        // Tworzenie okna
        window = GLFW.glfwCreateWindow(800, 600, "gra", 0, 0);
        if (window == 0) {
            throw new RuntimeException("Nie można stworzyć okna");
        }


        // Ustawienie kontekstu
        GLFW.glfwMakeContextCurrent(window);
        GLFW.glfwShowWindow(window);
        GL.createCapabilities();

        shaderProgram = new Shader("C:\\Users\\V15FRANEK\\IdeaProjects\\OpenGLLearn\\src\\main\\resources\\shader.vs", "C:\\Users\\V15FRANEK\\IdeaProjects\\OpenGLLearn\\src\\main\\resources\\shader.fs");
        textureID[0] = TextureLoader.loadTexture("C:\\Users\\V15FRANEK\\IdeaProjects\\OpenGLLearn\\src\\main\\resources\\texture.jpg");
        textureID[1] = TextureLoader.loadTexture("C:\\Users\\V15FRANEK\\IdeaProjects\\OpenGLLearn\\src\\main\\resources\\textureFace.jpg");

        // Ustawienie widoku (viewport)
        GL46.glViewport(0, 0, 800, 600);

        // Callback przy zmianie rozmiaru okna (opcjonalnie, jeśli wymagane)
        GLFW.glfwSetFramebufferSizeCallback(window, (win, width, height) -> {
            GL46.glViewport(0, 0, width, height);
        });


        //VAO piersszego torjkąta

        GL46.glGenVertexArrays(VAO);
        GL46.glGenBuffers(VBO);
        GL46.glGenBuffers(EBO);

        GL46.glBindVertexArray(VAO[0]);



        GL46.glBindBuffer(GL46.GL_ARRAY_BUFFER, VBO[0]);
        GL46.glBufferData(GL46.GL_ARRAY_BUFFER, vertices, GL46.GL_STATIC_DRAW);


        GL46.glBindBuffer(GL46.GL_ELEMENT_ARRAY_BUFFER, EBO[0]);
        GL46.glBufferData(GL46.GL_ELEMENT_ARRAY_BUFFER, indices, GL46.GL_STATIC_DRAW);

        GL46.glVertexAttribPointer(0, 3, GL46.GL_FLOAT, false, 5 * Float.BYTES, 0);
        GL46.glEnableVertexAttribArray(0);

        GL46.glVertexAttribPointer(1,2, GL46.GL_FLOAT, false,5*Float.BYTES,3*Float.BYTES);
        GL46.glEnableVertexAttribArray(1);










    }

    private void loop(){
        while (!GLFW.glfwWindowShouldClose(window)) {
            processInput();

            time = (float) GLFW.glfwGetTime();
            GL46.glClearColor(0.1f, 0.2f, 0.3f, 1.0f);
            GL46.glClear(GL46.GL_COLOR_BUFFER_BIT);



            shaderProgram.useShaderProgram();
            shaderProgram.setIntUniform("ourTexture", 0);
            shaderProgram.setIntUniform("ourTexture1", 1);
            shaderProgram.setFloatUniform("textureView", mixValue);

            Matrix4f modelMatrix = new Matrix4f().rotate((float) Math.toRadians(-55.0f), 1.0f, 0.0f, 0.0f);
            Matrix4f viewMatrix = new Matrix4f().translate(0.0f, 0.0f, -3.0f);
            Matrix4f projectionMatrix = new Matrix4f().perspective((float) Math.toRadians(45.0f), 800f / 600f, 0.1f, 100.0f);

            shaderProgram.setMatrix4fUniform("modelMatrix", modelMatrix);
            shaderProgram.setMatrix4fUniform("viewMatrix", viewMatrix);
            shaderProgram.setMatrix4fUniform("projectionMatrix", projectionMatrix);



            GL46.glActiveTexture(GL46.GL_TEXTURE0);
            GL46.glBindTexture(GL46.GL_TEXTURE_2D, textureID[0]);
            GL46.glActiveTexture(GL46.GL_TEXTURE1);
            GL46.glBindTexture(GL46.GL_TEXTURE_2D, textureID[1]);

            GL46.glBindVertexArray(VAO[0]);
            GL46.glDrawElements(GL46.GL_TRIANGLES, 6, GL46.GL_UNSIGNED_INT, 0);






            GLFW.glfwPollEvents();
            GLFW.glfwSwapBuffers(window);




        }
    }



    private void processInput() {
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_ESCAPE) == GLFW.GLFW_PRESS) {
            GLFW.glfwSetWindowShouldClose(window, true);

        }
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_UP) == GLFW.GLFW_PRESS){
            mixValue = mixValue + 0.001f;
            if(mixValue >= 1.0f){
                mixValue = 1.0f;
            }
        }

        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_DOWN) == GLFW.GLFW_PRESS){
            mixValue = mixValue - 0.001f;
            if(mixValue <= 0.0f){
                mixValue = 0.0f;
            }
        }
    }

    private void ending(){
        GLFW.glfwDestroyWindow(window);
        GLFW.glfwTerminate();
        GLFW.glfwSetErrorCallback(null).free();

    }
}

